#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>

int main(){
	
	//pid_t cpid;
	int cpid;
	//printf("Before fork()\n");
	//cpid = vfork(); 
	cpid = fork();
	if (cpid == -1){
		printf("Fork failed\n");
		exit(1);
	}
	
	else
		printf("pid: %d, ppid:%d\n",getpid(), getppid());
	return 0;
}



//this function shows a pid or ppid of a process when we fork()
