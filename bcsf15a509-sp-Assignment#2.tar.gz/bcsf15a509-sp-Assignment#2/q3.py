import sys 

def find(matrix,mat2x2):
	matrix = [int(i) for i in matrix] 
	c = 0
	row = 0 
	col = 0
	for row in range(7):
		for c in range(7):
			if matrix[col] is mat2x2[row][c] and matrix[col + 1] is mat2x2[row][c+1] and matrix[col+ 2] is mat2x2[row+1][c] 				and  matrix[col + 3] is mat2x2[row+1][c+1]:
				print "Matrix found at (%d,%d)" %(row,c)
				return; 
			c = c + 1
		row = row + 1
	print "Matrix not found"
	return;
	

if __name__ == "__main__":
	mat8x8 = [[1,2,3,4,5,6,7,8],
	 [2,3,4,5,6,7,8,9],
	 [3,4,5,6,7,8,9,10],
	 [4,5,6,7,8,9,10,11],
	 [5,6,7,8,9,10,11,12],
	 [6,7,8,9,10,11,12,13],
	 [7,8,9,10,11,12,13,14],
	 [8,9,10,11,12,13,14,15]]
	
	if len(sys.argv[1:]) == 4 :	
		findMatrix(sys.argv[1:],mat8x8)
	else :
		print "not a 2x2 matrix"
	

