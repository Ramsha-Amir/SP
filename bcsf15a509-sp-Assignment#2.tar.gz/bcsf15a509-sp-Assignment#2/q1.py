import requests
from PIL import Image
from bs4 import BeautifulSoup
from StringIO import StringIO
from datetime import datetime
import os
import urllib

def get(URL):

	req = requests.get(URL,stream =True)
	mp3_links = []
	if req.status_code == 200:
		parser_obj = BeautifulSoup(req.content, "html.parser")
		href_tag_list = parser_obj.find_all("a")
		for href_tag in href_tag_list[1:]:
			mp3_links.append(href_tag['href'])
	return mp3_links

def download(url_list):
	c = 0
	path = "/home/sidra/Desktop/folder"
	for mp3_url in url_list:
		URL = "https://download.quranicaudio.com/quran/"+mp3_url
		mp3_links = get_mp3(URL)
		mp3_links = mp3_links[-26:]
		directory = path+mp3_url[:-1]
		os.mkdir(directory)
		os.chdir(directory)


def main():
	URL = "https://download.quranicaudio.com/quran/"
	list1 = get(URL)
	download(list1)

	if __name__ == "__main__":
		main()
