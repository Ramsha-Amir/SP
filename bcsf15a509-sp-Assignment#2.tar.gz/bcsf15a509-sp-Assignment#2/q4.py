import psutil 
import sys
import os
import time
import requests
from PIL import Image
from bs4 import BeautifulSoup
from StringIO import StringIO
import urllib


arg = psutil.Process(int(sys.argv[1]))
print "pid: ", arg.pid
print "Name: ", arg.name
print "Status: ", arg.status
print "Parent ID: ", arg.ppid
print "Parent Name: ", psutil.Process(arg.ppid).name
print "Creation Time:", time.ctime(arg.create_time)
print "Files open:", arg.get_open_files()
print "Memory:", arg.get_memory_info()
