#!/bin/bash
declare -i username
username=$1


if [ $# = 0 ]
then 
 echo "zero argument passed"
exit 0
fi


if [ $# != 1 ]
then 
 echo "only one  argument passed"
exit 1
fi



showAllOwner()
{	
	for fname in `ls` 
	do 
	
		if [ -f $fname ]
		then	
	
			set `ls -li $fname`
		
			if [ $username=$4 ]
			then
				echo "Filename: $fname   Filetype: File owner: $4"
				
			fi
		fi
	done	
	
	
}

showAllOwner  
