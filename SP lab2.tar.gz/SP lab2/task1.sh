#!/bin/bash


declare -i first
declare -i second
declare -i third
declare -i four
declare -i five
declare -i six

first=$1
second=$2
third=$3
four=$4
five=$5
six=$6


#check whether its a number on first argument 

x=`expr $1+1`
if [ $? != 0 ]
then 
	echo "first argument is not a number"
exit 1
fi


#check whether its a number  on third argument

x=`expr $3+1`
if [ $? != 0 ]
then 
	echo "third argument is not a number"
exit 2
fi



#check whether its a number  on fifth argument

x=`expr $5+1`
if [ $? != 0 ]
then 
	echo "fifth argument is not a number"
exit 3
fi


#Print table according to checks

print-table()
{
	#if only 1 argument
####################################################
	if [ $# = 1 ]
	then
		for ctr in `seq 1 10`
		do
			echo "$first * $ctr = `expr $first \* $ctr` "		
		done
		#if only 2 argument
####################################################

	elif [ $# = 2 ]
	then
		for ctr in `seq $2 10`
		do
			echo "$first * $ctr = `expr $first \* $ctr` "		
		done

	#elif [ $# = 3 ]
	#then
	#	for ctr in `seq $second $third`
	#	do
	#		echo "$first * $ctr = `expr $first \* $ctr` "		
	#	done
	#



	#if only 3 argument
####################################################
	elif [ $# = 3 ]
	then
		if [ $second=-s ]
		then
			for ctr in `seq $third 10`
			do
				echo "$first * $ctr = `expr $first \* $ctr` "		
			done
		fi


	#if only 5 argument
####################################################
	elif [ $# = 5 ]
	then
		if [ $second=-s -a $four=-e  ]
		then
		echo "ab"
		for ctr in `seq $third $five`
		do
			echo "$first * $ctr = `expr $first \* $ctr` "		
		done
		fi



	#if only 6 argument
####################################################
	elif [ $# = 6 ]
	then
		if [ $second=-s -a $four=-e -a $six=-r ]
		then
		
		for ctr in `seq $five $third`
		do
		#echo "abxc"
			echo "$first * $ctr = `expr $first \* $ctr`"		
		done
	
		fi

	#if zero argument
####################################################
	
else 
	echo "No argument is entered. please enter some arguments from 1 to 6"
fi
		
exit 0

}


print-table $@






