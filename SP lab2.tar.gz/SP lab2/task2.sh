#!/bin/bash

#+++++without commandline arguments++++ 

#temp=`pidof bash`
#cd /proc/`pidof bash` grep $temp && cat status |  grep "PPid"  && cat status | grep "Pid" && cat status | grep "Name" && cat status | grep "State" 



#+++++with commandline arguments++++ 


nameOfProcess=$1
set `pidof $nameOfProcess`
PID=$2
echo "PID :$PID"
echo "Name : $nameOfProcess "

cd /proc/$PID/ && cat status | grep "PPid" && cat status | grep "State"
