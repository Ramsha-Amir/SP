#!/bin/bash


file1=$1
user_Name1=$2
file2=$3
user_Name2=$4


echo $'Data of file1:\n'
set `ls -li $1`
if [ $4 = $user_Name1 ]
then  	
	echo "     OWNER: $4"
	echo "     GROUP: $5"
	echo "     PERMISSIONS: $2"
	echo "     FILENAME: $file1"
	echo "     cheating : 0"
else 
	echo "     cheating : 1"
fi


echo $'Data of file2:\n'
set `ls -li $3`
if [ $4 = $user_Name2 ]
then  	
	echo "     OWNER: $4"
	echo "     GROUP: $5"
	echo "     PERMISSIONS: $2"
	echo "     FILENAME: $file1"
	echo "     cheating : 0"
else 
	echo "     cheating : 1"
fi

echo "The difference between two files are: "
     diff -c $file1 $file2










