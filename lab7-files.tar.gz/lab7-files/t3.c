#include<stdio.h>
#include<stdlib.h>
#include<fcntl.h>

int main()
{	int fd;
	int n1;
	int n2;
	char buff[256];
	while(1){
		fd=open("data.txt",O_CREAT | O_RDWR);
		n1=read(0,buff,255);
		if(n1==-1)
		{
			perror("Error in reading file");
			exit(1);
		
		}
		n2=write(fd,buff,n1);
		if(n2==-1)
		{
			perror("Error in writing file");
			exit(1);
		
		}
		
	}
	return 0;
}
