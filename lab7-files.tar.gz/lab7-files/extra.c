#include<stdio.h>
#include<stdlib.h>
#include<fcntl.h>

int main(int argc , char * argv[])
{
	int fd;
	if(argc!=1)
	{
		close(1);
		fd=open(argv[1],O_CREAT | O_RDWR);
	}
	printf("abcd\n");
	return 0; 
}
