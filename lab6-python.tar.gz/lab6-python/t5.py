n=raw_input()
#l=[]
n=n.upper()
#l=l.append(n.upper())
print n
