n=input("Enter words: ")
list1 =[]
li=n.split(" ")
li.sort()
s=set(li)
for words in s:
	list1.append(words)
list1.sort()
print (list1)

