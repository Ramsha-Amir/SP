n=raw_input("prompt")
l=[]
#s=()
n.split(',')	
l.append(n)	
s=tuple(l)
print l
print s
	


