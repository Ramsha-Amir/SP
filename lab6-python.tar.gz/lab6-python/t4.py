n=raw_input()
l=[]	
l=n.split(" ")	
l.sort()
print l
