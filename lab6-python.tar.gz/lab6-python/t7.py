n=raw_input()
count1=0
count2=0

for num in n:
	if num.isdigit():
		count1=count1+1
	else: 
		count2=count2+1
print count1
print count2

