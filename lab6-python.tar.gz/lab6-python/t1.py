n=range(2000,3200)
l=[]
for num in n:
	if num%7==0 and num%5!=0:
		#num=num.split(',')
		l.append(num)

print l		
