import calendar
y=int(input("enter year"))
m=int(input("enter month"))
print(calendar.month(y,m))

'''import calendar
x=calendar.month(2018,4)
print(x)'''

