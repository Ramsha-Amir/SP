#!/bin/bash
 
file=$1
ctr=0
 

touch even
touch odd

#check argument is passed or not
if [ $# -eq 0 ]
then
	echo "zero argument passed. please pass only one argument"
fi

#check file exist or not
if [ ! -f $file ]
then 
	echo "$file is not a file"
fi
 

#check the lines and transfer these lines to odd or even file
while read line
do
  
 e=$( expr $ctr % 2 )
 
 	if [ $e -ne 0 ] 
 	then
 		echo $line >> even 2> err
	 else
		echo $line >> odd 2> err
	 fi
 
 (( ctr ++ ))
done < $file

