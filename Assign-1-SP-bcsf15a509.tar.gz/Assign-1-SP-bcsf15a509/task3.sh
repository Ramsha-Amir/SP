#!/bin/bash

#Is_lower() Purpose: Converts a string to lower case

Is_lower()
{
	a="ABGGD GDHHSJ"
	b="$(echo $a | tr '[A-Z]' '[a-z]')"

	echo "$b"
}

#Is_root() Purpose: Return true if script is executed by the root user
Is_root()
{
	if  [ $(id -u) = 0 ]
	then
  		 echo "by root"
	else 
		echo "not by root"
   		
	fi

}

#Is_user_exists() Purpose: Return true $user exits in /etc/passwd
Is_user_exists()
{
	user=$1
	#user=abc
	for username in cut -d ":" -f 1 /etc/passwd
	do
		
		if [ $username=$user ]
		then
			echo "Matched"
		else
			echo "not matched"
		fi
	done


}


#Is_user_exists()
#{
#	user=$1
#	if getent passwd $user > /dev/null 2>&1
#	then
#  		 echo "yes the user exists"
#	else
#    		echo "No, the user does not exist"
#	fi
#}




Is_root
Is_user_exists

