#!/bin/bash
#Remove duplicate lines from  a file

file=$1

if [ $# -eq 0 ]
then
	echo "zero argument passed. please pass only one argument"
	exit 1
fi


if [ -f $file ]
then

	sort $file | uniq -u 1> out && echo "duplicate line from $file are removed" 
else
	echo "not file"
fi
