##suppose i have some files of different extensions check the extensions and make a folder of that extension and move all files to that #folder with same extensions in same folder.

#!/bin/bash

for file in `ls`
do
	if [ -f $file ]
	then
################### .txt #################
		if [ *.txt ]
		then
			if [ -d TXT ]
			then
				`mv *.txt TXT 2> out`
			else
				`mkdir TXT` && `mv *.txt TXT 2> out`
			 	
			fi
		fi


################### .doc #################
		if [ *.doc ]
		then
			if [ -d DOC ]
			then
				`mv *.doc DOC 2> out`
			else
				`mkdir DOC` && `mv *.doc DOC 2> out`
			 	
			fi
		fi
################### .mp3 #################

		if [ *.mp3 ]
		then
			if [ -d MP3 ]
			then
				`mv *.mp3 MP3 2> out`
			else
				`mkdir MP3` && `mv *.mp3 MP3 2> out`
			 	
			fi
	
		fi		

################### .mp4 #################
		if [ *.mp4 ]
		then
			if [ -d MP4 ]
			then
				`mv *.mp4 MP4 2> out`
			else
				`mkdir MP4` && `mv *.mp4 MP4 2> out`
			 	
			fi
		fi

################### .csv #################
		if [ *.csv ]
		then
			if [ -d CSV ]
			then
				`mv *.csv CSV 2> out`
			else
				`mkdir CSV` && `mv *.csv CSV 2> out`
			 	
			fi
		#else
			#echo "No such file or directory of type txt :/"
		fi
	#else 
		#echo "No such file or directory of type txt :/"

	fi
done
