#include<stdio.h>
#include "myMath.h"
//#include "myStr.h"

int main()
{
	int x,y;
	printf("Enter num1 : ");
	scanf("%d",&x);
	printf("Enter num2 : ");
	scanf("%d",&y);
	int swapp = swap(x,y);
	int Equal = isEqual(x,y);
	printf ("swap %d and %d = %d \n", x,y,swapp);
	printf ("isEqual %d and %d = %d ", x,y,Equal);
	printf ("\n");
	return 0;
}
