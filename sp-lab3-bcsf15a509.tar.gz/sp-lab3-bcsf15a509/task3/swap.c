int swap(int a, int b)
{	
	//a=1;
	//b=2;
	a=a+b;
	b=a-b;
	a=a-b;
	return 0;
}
