int isPalindrome(char*, int);
