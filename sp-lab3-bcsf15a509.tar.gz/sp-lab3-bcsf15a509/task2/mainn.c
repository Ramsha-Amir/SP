#include<stdio.h>
#include<string.h>
#include "myStr.h"
int main()
{
	int size=9;
	char str[9]="eeebeee";
	if(isPalindrome(str,size) == 1)
	{
		printf ("yes\n");
	
	}
	else
	{
		printf ("not\n");
	}
	
	
	
	
	printf ("\n");
	return 0;
}
