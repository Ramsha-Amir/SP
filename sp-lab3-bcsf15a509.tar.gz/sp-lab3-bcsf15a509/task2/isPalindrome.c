int isPalindrome(char *str, int size)
{
	int i;
   	if (size<1) 
         	return 1;
  	if (str[0] == str[size-1])                                 
         	return isPalindrome (str+1, size-2);    
   	else
         	return 0;                                         
   
}
