int isEqual(int x, int y)
{	
	//$x -eq $y && echo "They are equal" || echo "Not Equal"
	if(x==y)
	{
		//printf ("equal");
		return 1;
	}	
	else
	{
		//printf ("not");
		return -1;
	}


	
}
