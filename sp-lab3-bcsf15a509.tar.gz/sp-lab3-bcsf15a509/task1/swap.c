#include<stdio.h>
int swap(int a, int b)
{	
	printf ("BEFORE swapping a= %d   b= %d ", a,b )
	a=a+b;
	b=a-b;
	a=a-b;
	printf ("swapping done a= %d   b= %d ", a,b )

	return 1;
}
