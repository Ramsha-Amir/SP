int isEqual(int, int);
int swap(int, int);
