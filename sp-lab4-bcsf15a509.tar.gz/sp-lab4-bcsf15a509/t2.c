#include <stdio.h>
//header file for brk() sbrk()
#include <sys/types.h>

int main()
{
	int *p1, *p2, *p3, *p4;

	//sbrk() doesn't change after every malloc() calls. Because
	//malloc() calls sbrk()with a large number
	printf("sbrk(0) before malloc(1): 0x%x\n", sbrk(0));
	

	p1 = (int *) malloc(1);
	printf("sbrk(0) after `p1 = (int *) malloc(1)': 0x%x\n",sbrk(0));

	p2 = (int *) malloc(2);
	printf("sbrk(0) after `p2 = (int *) malloc(2)': 0x%x\n",sbrk(0));

	p3 = (int *) malloc(3);
	printf("sbrk(0) after `p2 = (int *) malloc(3)': 0x%x\n",sbrk(0));

	p4 = (int *) malloc(4);
	printf("sbrk(0) after `p2 = (int *) malloc(4)': 0x%x\n",sbrk(0));
	

	//Now all the values of p1 p2 p3 p4 are different. it takes more bytes as some bytes taken by itself for its own information 
	//p1 p2 p3 p4 consumes same bytes which we have allocate or demand.
	printf("p1 = 0x%x\np2 = 0x%x\np3 = 0x%x\np4 = 0x%x\n", p1, p2, p3, p4);

free(p1);
free(p2);
free(p3);
free(p4);
return 0;
}
