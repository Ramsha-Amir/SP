#include<stdio.h>
#include<setjmp.h>

int counter=0;
static jmp_buf env;

void haveFun()
{	counter=counter+1;
	printf("value of counter in HaveFun is %d\n", counter);
	longjmp(env,counter++);
}



void firstSetJump()
{
	if ((counter = setjmp(env)) == 0)
	{
		
		counter=counter+1;
		printf("value of counter in firstSetJump is %d\n", counter);
		longjmp(env,counter++);
		//haveFun();
	}
	
	
}


int main()
{
	if ((counter = setjmp(env)) == 0)
	{
		printf("In main Value of counter = %d\n", counter);
		firstSetJump();
		printf("After firstSetJUmp() Value of counter = %d\n", counter);
		
	}
	
	haveFun();
	printf("After haveFun() Value of counter = %d\n", counter);
	
	
	
return 0;
}
	





