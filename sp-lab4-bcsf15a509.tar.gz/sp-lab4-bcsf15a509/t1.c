#include<stdio.h>
#include<stdlib.h>
//extern int *arr;


int main()
{	int i;
	int size=10;
	
	int *arr=(int*)malloc(sizeof(int)*size);
	if(arr==NULL)
		perror("malloc failed \n");
	
	for(i=0;i<size;i++)
	{
		arr[i]=i;
	}
	
	//print array1
	printf ("Data of array 1 is :\n);
	for(i=0; i<size; i++)
	{
		printf ("data of arr1 %d \n" ,arr[i]);
	}	
	
	//new array with double size new:
	
	int new=20;
	int *arr2=(int*)realloc(arr, sizeof(int)*size);
	if (arr2==NULL)
		perror("realoc failed \n");
	else
		arr=arr2;
	
	int k=10;
	for(i=size;i<new;i++)
	{
		//k++
		arr[i]=k++;
	}
	

	//print array2
	printf ("Data of array 2 is :\n);
	for(i=0; i<new; i++)
	{
		printf ("%d",arr[i]);
	}

	free(arr);
	
	
	
return 0;
}
